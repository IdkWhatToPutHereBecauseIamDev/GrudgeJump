gdjs.GameSceneCode = {};
gdjs.GameSceneCode.localVariables = [];
gdjs.GameSceneCode.idToCallbackMap = new Map();
gdjs.GameSceneCode.GDIndicatorArrowObjects1_1final = [];

gdjs.GameSceneCode.GDMobileButtonObjects1_1final = [];

gdjs.GameSceneCode.GDMobileButtonObjects2_1final = [];

gdjs.GameSceneCode.GDPlayerObjectObjects1_1final = [];

gdjs.GameSceneCode.GDWallsObjects1_1final = [];

gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final = [];

gdjs.GameSceneCode.forEachIndex2 = 0;

gdjs.GameSceneCode.forEachObjects2 = [];

gdjs.GameSceneCode.forEachTemporary2 = null;

gdjs.GameSceneCode.forEachTotalCount2 = 0;

gdjs.GameSceneCode.GDPlayerObjectObjects1= [];
gdjs.GameSceneCode.GDPlayerObjectObjects2= [];
gdjs.GameSceneCode.GDPlayerObjectObjects3= [];
gdjs.GameSceneCode.GDPlayerObjectObjects4= [];
gdjs.GameSceneCode.GDPlayerObjectObjects5= [];
gdjs.GameSceneCode.GDSawObjects1= [];
gdjs.GameSceneCode.GDSawObjects2= [];
gdjs.GameSceneCode.GDSawObjects3= [];
gdjs.GameSceneCode.GDSawObjects4= [];
gdjs.GameSceneCode.GDSawObjects5= [];
gdjs.GameSceneCode.GDPickUpObjects1= [];
gdjs.GameSceneCode.GDPickUpObjects2= [];
gdjs.GameSceneCode.GDPickUpObjects3= [];
gdjs.GameSceneCode.GDPickUpObjects4= [];
gdjs.GameSceneCode.GDPickUpObjects5= [];
gdjs.GameSceneCode.GDIndicatorArrowObjects1= [];
gdjs.GameSceneCode.GDIndicatorArrowObjects2= [];
gdjs.GameSceneCode.GDIndicatorArrowObjects3= [];
gdjs.GameSceneCode.GDIndicatorArrowObjects4= [];
gdjs.GameSceneCode.GDIndicatorArrowObjects5= [];
gdjs.GameSceneCode.GDWallsObjects1= [];
gdjs.GameSceneCode.GDWallsObjects2= [];
gdjs.GameSceneCode.GDWallsObjects3= [];
gdjs.GameSceneCode.GDWallsObjects4= [];
gdjs.GameSceneCode.GDWallsObjects5= [];
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1= [];
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2= [];
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects3= [];
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects4= [];
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects5= [];
gdjs.GameSceneCode.GDScoreObjects1= [];
gdjs.GameSceneCode.GDScoreObjects2= [];
gdjs.GameSceneCode.GDScoreObjects3= [];
gdjs.GameSceneCode.GDScoreObjects4= [];
gdjs.GameSceneCode.GDScoreObjects5= [];
gdjs.GameSceneCode.GDPickUpUIObjects1= [];
gdjs.GameSceneCode.GDPickUpUIObjects2= [];
gdjs.GameSceneCode.GDPickUpUIObjects3= [];
gdjs.GameSceneCode.GDPickUpUIObjects4= [];
gdjs.GameSceneCode.GDPickUpUIObjects5= [];
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects1= [];
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects2= [];
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects3= [];
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects4= [];
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects5= [];
gdjs.GameSceneCode.GDBackgroundObjects1= [];
gdjs.GameSceneCode.GDBackgroundObjects2= [];
gdjs.GameSceneCode.GDBackgroundObjects3= [];
gdjs.GameSceneCode.GDBackgroundObjects4= [];
gdjs.GameSceneCode.GDBackgroundObjects5= [];
gdjs.GameSceneCode.GDChatTextObjects1= [];
gdjs.GameSceneCode.GDChatTextObjects2= [];
gdjs.GameSceneCode.GDChatTextObjects3= [];
gdjs.GameSceneCode.GDChatTextObjects4= [];
gdjs.GameSceneCode.GDChatTextObjects5= [];
gdjs.GameSceneCode.GDChatInputObjects1= [];
gdjs.GameSceneCode.GDChatInputObjects2= [];
gdjs.GameSceneCode.GDChatInputObjects3= [];
gdjs.GameSceneCode.GDChatInputObjects4= [];
gdjs.GameSceneCode.GDChatInputObjects5= [];
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects1= [];
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects2= [];
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects3= [];
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects4= [];
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects5= [];
gdjs.GameSceneCode.GDSendButtonObjects1= [];
gdjs.GameSceneCode.GDSendButtonObjects2= [];
gdjs.GameSceneCode.GDSendButtonObjects3= [];
gdjs.GameSceneCode.GDSendButtonObjects4= [];
gdjs.GameSceneCode.GDSendButtonObjects5= [];
gdjs.GameSceneCode.GDSpawnPointObjects1= [];
gdjs.GameSceneCode.GDSpawnPointObjects2= [];
gdjs.GameSceneCode.GDSpawnPointObjects3= [];
gdjs.GameSceneCode.GDSpawnPointObjects4= [];
gdjs.GameSceneCode.GDSpawnPointObjects5= [];
gdjs.GameSceneCode.GDPlayerNameObjects1= [];
gdjs.GameSceneCode.GDPlayerNameObjects2= [];
gdjs.GameSceneCode.GDPlayerNameObjects3= [];
gdjs.GameSceneCode.GDPlayerNameObjects4= [];
gdjs.GameSceneCode.GDPlayerNameObjects5= [];
gdjs.GameSceneCode.GDCameraLimitsLeftObjects1= [];
gdjs.GameSceneCode.GDCameraLimitsLeftObjects2= [];
gdjs.GameSceneCode.GDCameraLimitsLeftObjects3= [];
gdjs.GameSceneCode.GDCameraLimitsLeftObjects4= [];
gdjs.GameSceneCode.GDCameraLimitsLeftObjects5= [];
gdjs.GameSceneCode.GDCameraLimitsRightObjects1= [];
gdjs.GameSceneCode.GDCameraLimitsRightObjects2= [];
gdjs.GameSceneCode.GDCameraLimitsRightObjects3= [];
gdjs.GameSceneCode.GDCameraLimitsRightObjects4= [];
gdjs.GameSceneCode.GDCameraLimitsRightObjects5= [];
gdjs.GameSceneCode.GDCameraLimitsTopObjects1= [];
gdjs.GameSceneCode.GDCameraLimitsTopObjects2= [];
gdjs.GameSceneCode.GDCameraLimitsTopObjects3= [];
gdjs.GameSceneCode.GDCameraLimitsTopObjects4= [];
gdjs.GameSceneCode.GDCameraLimitsTopObjects5= [];
gdjs.GameSceneCode.GDCameraLimitsBottomObjects1= [];
gdjs.GameSceneCode.GDCameraLimitsBottomObjects2= [];
gdjs.GameSceneCode.GDCameraLimitsBottomObjects3= [];
gdjs.GameSceneCode.GDCameraLimitsBottomObjects4= [];
gdjs.GameSceneCode.GDCameraLimitsBottomObjects5= [];
gdjs.GameSceneCode.GDMobileButtonObjects1= [];
gdjs.GameSceneCode.GDMobileButtonObjects2= [];
gdjs.GameSceneCode.GDMobileButtonObjects3= [];
gdjs.GameSceneCode.GDMobileButtonObjects4= [];
gdjs.GameSceneCode.GDMobileButtonObjects5= [];
gdjs.GameSceneCode.GDTutorialTextObjects1= [];
gdjs.GameSceneCode.GDTutorialTextObjects2= [];
gdjs.GameSceneCode.GDTutorialTextObjects3= [];
gdjs.GameSceneCode.GDTutorialTextObjects4= [];
gdjs.GameSceneCode.GDTutorialTextObjects5= [];


gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects = Hashtable.newFrom({"PlayerObject": gdjs.GameSceneCode.GDPlayerObjectObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorArrowObjects2Objects = Hashtable.newFrom({"IndicatorArrow": gdjs.GameSceneCode.GDIndicatorArrowObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerNameObjects1Objects = Hashtable.newFrom({"PlayerName": gdjs.GameSceneCode.GDPlayerNameObjects1});
gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MobileButton"), gdjs.GameSceneCode.GDMobileButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.GameSceneCode.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDMobileButtonObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDMobileButtonObjects2[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDTutorialTextObjects2[i].getBehavior("Opacity").setOpacity(200);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TutorialText"), gdjs.GameSceneCode.GDTutorialTextObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDTutorialTextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDTutorialTextObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameSceneCode.GDSpawnPointObjects1, gdjs.GameSceneCode.GDSpawnPointObjects2);

gdjs.GameSceneCode.GDPlayerObjectObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects, (( gdjs.GameSceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects2[0].getPointX("")), (( gdjs.GameSceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("MultiplayerObject").takeObjectOwnership();
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("MultiplayerObject").enableBehaviorSynchronization("SmoothCamera", false);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").enableLayer(gdjs.multiplayer.getCurrentPlayerNumber() + 1, true);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects2);
gdjs.copyArray(gdjs.GameSceneCode.GDSpawnPointObjects1, gdjs.GameSceneCode.GDSpawnPointObjects2);

gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorArrowObjects2Objects, (( gdjs.GameSceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects2[0].getPointX("")), (( gdjs.GameSceneCode.GDSpawnPointObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].setZOrder((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getZOrder()) - 1);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("MultiplayerObject").takeObjectOwnership();
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameSceneCode.GDSpawnPointObjects1 */
gdjs.GameSceneCode.GDPlayerNameObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerNameObjects1Objects, (( gdjs.GameSceneCode.GDSpawnPointObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects1[0].getPointX("")), (( gdjs.GameSceneCode.GDSpawnPointObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDSpawnPointObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerNameObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerNameObjects1[i].getBehavior("Text").setText(gdjs.multiplayer.getCurrentPlayerUsername());
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerNameObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerNameObjects1[i].getBehavior("MultiplayerObject").takeObjectOwnership();
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerNameObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerNameObjects1[i].getBehavior("Opacity").setOpacity(150);
}
}
}

}


};gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects2, gdjs.GameSceneCode.GDPlayerObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects3[i].behaviorActivated("SmoothCamera") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects3[k] = gdjs.GameSceneCode.GDPlayerObjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].activateBehavior("SmoothCamera", false);
}
}
}

}


};gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ChatText"), gdjs.GameSceneCode.GDChatTextObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDChatTextObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDChatTextObjects2[i].setBBText("");
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ChatInput"), gdjs.GameSceneCode.GDChatInputObjects2);
gdjs.copyArray(runtimeScene.getObjects("SendButton"), gdjs.GameSceneCode.GDSendButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDSendButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDSendButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDSendButtonObjects2[k] = gdjs.GameSceneCode.GDSendButtonObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDSendButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDChatInputObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDChatInputObjects2[i].getBehavior("Text").getText() != "" ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDChatInputObjects2[k] = gdjs.GameSceneCode.GDChatInputObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDChatInputObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDChatInputObjects2 */
{gdjs.multiplayerMessageManager.sendCustomMessage("PlayerChat", (( gdjs.GameSceneCode.GDChatInputObjects2.length === 0 ) ? "" :gdjs.GameSceneCode.GDChatInputObjects2[0].getText()));
}
{for(var i = 0, len = gdjs.GameSceneCode.GDChatInputObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDChatInputObjects2[i].getBehavior("Text").setText("");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.multiplayerMessageManager.hasCustomMessageBeenReceived("PlayerChat");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ChatInput"), gdjs.GameSceneCode.GDChatInputObjects1);
gdjs.copyArray(runtimeScene.getObjects("ChatText"), gdjs.GameSceneCode.GDChatTextObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDChatTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDChatTextObjects1[i].setBBText(gdjs.GameSceneCode.GDChatTextObjects1[i].getBBText() + (gdjs.evtTools.string.newLine() + "[b]" + gdjs.multiplayer.getPlayerUsername((gdjs.multiplayerMessageManager.getCustomMessageSender("PlayerChat"))) + "[/b]: " + gdjs.multiplayerMessageManager.getCustomMessageData("PlayerChat")));
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDChatTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDChatTextObjects1[i].setY((( gdjs.GameSceneCode.GDChatInputObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDChatInputObjects1[0].getY()) - (gdjs.GameSceneCode.GDChatTextObjects1[i].getHeight()));
}
}
}

}


};gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects3, gdjs.GameSceneCode.GDPlayerObjectObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects4[i].getVariableBoolean(gdjs.GameSceneCode.GDPlayerObjectObjects4[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects4[k] = gdjs.GameSceneCode.GDPlayerObjectObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects3, gdjs.GameSceneCode.GDIndicatorArrowObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects4[i].setAngle(15);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects4[i].getBehavior("Tween").addObjectAngleTween2("Left", 165, "linear", 1.5, false);
}
}
}

}


{

/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getVariableBoolean(gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects3[k] = gdjs.GameSceneCode.GDPlayerObjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].setAngle(165);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").addObjectAngleTween2("Right", 15, "linear", 1.5, false);
}
}
}

}


};gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects2, gdjs.GameSceneCode.GDIndicatorArrowObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getBehavior("Physics2").getLinearVelocityLength() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects3[k] = gdjs.GameSceneCode.GDPlayerObjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects3[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").exists("Left")) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects3[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").exists("Right")) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects3[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13852772);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects3 */
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getVariables().getFromIndex(0)).toggle();
}
}

{ //Subevents
gdjs.GameSceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects2, gdjs.GameSceneCode.GDIndicatorArrowObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").hasFinished("Left") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects3[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").removeTween("Left");
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").addObjectAngleTween2("Right", 15, "linear", 1.5, false);
}
}
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects2, gdjs.GameSceneCode.GDIndicatorArrowObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").hasFinished("Right") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects3[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").removeTween("Right");
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects3[i].getBehavior("Tween").addObjectAngleTween2("Left", 165, "linear", 1.5, false);
}
}
}

}


{



}


{

/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects2 */
gdjs.GameSceneCode.GDMobileButtonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameSceneCode.GDMobileButtonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MobileButton"), gdjs.GameSceneCode.GDMobileButtonObjects3);
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDMobileButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDMobileButtonObjects3[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDMobileButtonObjects3[k] = gdjs.GameSceneCode.GDMobileButtonObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDMobileButtonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDMobileButtonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDMobileButtonObjects2_1final.indexOf(gdjs.GameSceneCode.GDMobileButtonObjects3[j]) === -1 )
            gdjs.GameSceneCode.GDMobileButtonObjects2_1final.push(gdjs.GameSceneCode.GDMobileButtonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDMobileButtonObjects2_1final, gdjs.GameSceneCode.GDMobileButtonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects2[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("Tween").removeTween("Right");
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("Tween").removeTween("Left");
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("Tween").addObjectScaleTween3("Prepare", 2, "linear", 1, false, true);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Charge", false, 50, gdjs.randomFloatInRange(0.8, 0.95));
}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorArrowObjects1Objects = Hashtable.newFrom({"IndicatorArrow": gdjs.GameSceneCode.GDIndicatorArrowObjects1});
gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects1[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects1 */
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getBehavior("Physics2").applyPolarImpulse((( gdjs.GameSceneCode.GDIndicatorArrowObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorArrowObjects1[0].getAngle()) + 180, ((( gdjs.GameSceneCode.GDIndicatorArrowObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorArrowObjects1[0].getBehavior("Scale").getScale()) * (( gdjs.GameSceneCode.GDIndicatorArrowObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorArrowObjects1[0].getBehavior("Scale").getScale())) / 6, (gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getCenterXInScene()), (gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getCenterYInScene()));
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Jump", false, 40 * ((( gdjs.GameSceneCode.GDIndicatorArrowObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorArrowObjects1[0].getBehavior("Scale").getScale()) / 2), gdjs.randomFloatInRange(0.75, 0.9));
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("Tween").removeTween("Prepare");
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("Scale").setScale(1);
}
}
}

}


};gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects1 */
gdjs.GameSceneCode.GDMobileButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameSceneCode.GDIndicatorArrowObjects1_1final.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects1, gdjs.GameSceneCode.GDIndicatorArrowObjects2);

for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("Tween").hasFinished("Prepare") ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects2[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1_1final.indexOf(gdjs.GameSceneCode.GDIndicatorArrowObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDIndicatorArrowObjects1_1final.push(gdjs.GameSceneCode.GDIndicatorArrowObjects2[j]);
    }
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = !(gdjs.evtTools.systemInfo.isMobile());
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("MobileButton"), gdjs.GameSceneCode.GDMobileButtonObjects2);
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDMobileButtonObjects2.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDMobileButtonObjects2[i].getBehavior("ButtonFSM").IsPressed(null)) ) {
        isConditionTrue_2 = true;
        gdjs.GameSceneCode.GDMobileButtonObjects2[k] = gdjs.GameSceneCode.GDMobileButtonObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDMobileButtonObjects2.length = k;
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.systemInfo.isMobile();
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDMobileButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDMobileButtonObjects1_1final.indexOf(gdjs.GameSceneCode.GDMobileButtonObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDMobileButtonObjects1_1final.push(gdjs.GameSceneCode.GDMobileButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects1_1final, gdjs.GameSceneCode.GDIndicatorArrowObjects1);
gdjs.copyArray(gdjs.GameSceneCode.GDMobileButtonObjects1_1final, gdjs.GameSceneCode.GDMobileButtonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorArrowObjects1Objects);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorArrowObjects1, gdjs.GameSceneCode.GDIndicatorArrowObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("Tween").exists("Prepare")) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects2[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.GameSceneCode.GDIndicatorArrowObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("Tween").exists("Prepare") ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects1[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects1[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList9 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList8(runtimeScene);
}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects3Objects = Hashtable.newFrom({"PlayerObject": gdjs.GameSceneCode.GDPlayerObjectObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSawObjects3Objects = Hashtable.newFrom({"Saw": gdjs.GameSceneCode.GDSawObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects = Hashtable.newFrom({"PlayerObject": gdjs.GameSceneCode.GDPlayerObjectObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDWalls_95959595SlipperyObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDWallsObjects2Objects = Hashtable.newFrom({"Walls_Slippery": gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2, "Walls": gdjs.GameSceneCode.GDWallsObjects2});
gdjs.GameSceneCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects3);

gdjs.copyArray(runtimeScene.getObjects("Saw"), gdjs.GameSceneCode.GDSawObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.haveObjectsStartedColliding(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects3Objects, "Physics2", gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDSawObjects3Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects3 */
/* Reuse gdjs.GameSceneCode.GDSawObjects3 */
{for(var i = 0, len = gdjs.GameSceneCode.GDSawObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDSawObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.1, 0, 0, 0, -(50), 0.2, false, null);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getBehavior("Physics2").setLinearVelocityX(0);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getBehavior("Physics2").setLinearVelocityY(0);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getBehavior("Physics2").applyPolarImpulse((gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getAngleToObject((gdjs.GameSceneCode.GDSawObjects3.length !== 0 ? gdjs.GameSceneCode.GDSawObjects3[0] : null))), 1, (gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getCenterXInScene()), (gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getCenterYInScene()));
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "Hurt", false, 50, gdjs.randomFloatInRange(0.8, 0.95));
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects3[i].getBehavior("Animation").setAnimationName("Hit");
}
}
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);

gdjs.copyArray(runtimeScene.getObjects("Walls"), gdjs.GameSceneCode.GDWallsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Walls_Slippery"), gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.haveObjectsStartedColliding(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects, "Physics2", gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDWalls_95959595SlipperyObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDWallsObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").getLinearVelocityLength() > 10 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Collide", false, 25, gdjs.randomFloatInRange(0.7, 0.85));
}
}

}


};gdjs.GameSceneCode.mapOfEmptyGDPickUpObjects = Hashtable.newFrom({"PickUp": []});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects = Hashtable.newFrom({"PlayerObject": gdjs.GameSceneCode.GDPlayerObjectObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects = Hashtable.newFrom({"PickUp": gdjs.GameSceneCode.GDPickUpObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects = Hashtable.newFrom({"PickUp": gdjs.GameSceneCode.GDPickUpObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects = Hashtable.newFrom({"PickUp": gdjs.GameSceneCode.GDPickUpObjects2});
gdjs.GameSceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PickUpUI"), gdjs.GameSceneCode.GDPickUpUIObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "PickUp", false, 75, 1);
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPickUpUIObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPickUpUIObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 20, 20, 20, 0.1, false, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PickUpUI"), gdjs.GameSceneCode.GDPickUpUIObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPickUpUIObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPickUpUIObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(2, 40, 40, 40, 0.1, false, null);
}
}
}

}


};gdjs.GameSceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.GameSceneCode.GDScoreObjects3);
{for(var i = 0, len = gdjs.GameSceneCode.GDScoreObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDScoreObjects3[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(10 - gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameSceneCode.mapOfEmptyGDPickUpObjects)) + "/10");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("PickUp"), gdjs.GameSceneCode.GDPickUpObjects2);
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPlayerObjectObjects2Objects, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDPickUpObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPickUpObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPickUpObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPickUpObjects2[i].deleteFromScene(runtimeScene);
}
}

{ //Subevents
gdjs.GameSceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").getLinearVelocityX() > 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13876964);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").getLinearVelocityX() < -(5) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13877884);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").getLinearVelocityY() < -(5) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}
}

}


{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Physics2").getLinearVelocityY() > 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Animation").setAnimationName("Fall");
}
}
}

}


{

/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects1 */
gdjs.GameSceneCode.GDWallsObjects1.length = 0;

gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameSceneCode.GDPlayerObjectObjects1_1final.length = 0;
gdjs.GameSceneCode.GDWallsObjects1_1final.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);

gdjs.copyArray(runtimeScene.getObjects("Walls"), gdjs.GameSceneCode.GDWallsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Walls_Slippery"), gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2);
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[i].isCollidingWithPoint((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("GroundCheck1")), (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("GroundCheck1"))) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[k] = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDWallsObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDWallsObjects2[i].isCollidingWithPoint((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("GroundCheck1")), (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("GroundCheck1"))) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDWallsObjects2[k] = gdjs.GameSceneCode.GDWallsObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDWallsObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDPlayerObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDPlayerObjectObjects1_1final.indexOf(gdjs.GameSceneCode.GDPlayerObjectObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDPlayerObjectObjects1_1final.push(gdjs.GameSceneCode.GDPlayerObjectObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameSceneCode.GDWallsObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDWallsObjects1_1final.indexOf(gdjs.GameSceneCode.GDWallsObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDWallsObjects1_1final.push(gdjs.GameSceneCode.GDWallsObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final.indexOf(gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final.push(gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);

gdjs.copyArray(runtimeScene.getObjects("Walls"), gdjs.GameSceneCode.GDWallsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Walls_Slippery"), gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2);
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[i].isCollidingWithPoint((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("GroundCheck2")), (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("GroundCheck2"))) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[k] = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDWallsObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDWallsObjects2[i].isCollidingWithPoint((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("GroundCheck2")), (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("GroundCheck2"))) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDWallsObjects2[k] = gdjs.GameSceneCode.GDWallsObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDWallsObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameSceneCode.GDPlayerObjectObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDPlayerObjectObjects1_1final.indexOf(gdjs.GameSceneCode.GDPlayerObjectObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDPlayerObjectObjects1_1final.push(gdjs.GameSceneCode.GDPlayerObjectObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameSceneCode.GDWallsObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDWallsObjects1_1final.indexOf(gdjs.GameSceneCode.GDWallsObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDWallsObjects1_1final.push(gdjs.GameSceneCode.GDWallsObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final.indexOf(gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[j]) === -1 )
            gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final.push(gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1_1final, gdjs.GameSceneCode.GDPlayerObjectObjects1);
gdjs.copyArray(gdjs.GameSceneCode.GDWallsObjects1_1final, gdjs.GameSceneCode.GDWallsObjects1);
gdjs.copyArray(gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1_1final, gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


};gdjs.GameSceneCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDPlayerObjectObjects1, gdjs.GameSceneCode.GDPlayerObjectObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Animation").getAnimationName() == "Hit" ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}
}

}


{

/* Reuse gdjs.GameSceneCode.GDPlayerObjectObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getBehavior("Animation").getAnimationName() != "Hit" ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects1[k] = gdjs.GameSceneCode.GDPlayerObjectObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList10(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList12(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList14(runtimeScene);
}


};gdjs.GameSceneCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameSceneCode.GDBackgroundObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 3, "Background", 0);
}
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameSceneCode.GDBackgroundObjects2.length !== 0 ? gdjs.GameSceneCode.GDBackgroundObjects2[0] : null), true, "Background", 0);
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameSceneCode.GDBackgroundObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBackgroundObjects1[i].setYOffset(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) / 3);
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDBackgroundObjects1[i].setXOffset(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0) / 3);
}
}
}

}


};gdjs.GameSceneCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SpawnPoint"), gdjs.GameSceneCode.GDSpawnPointObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDSpawnPointObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDSpawnPointObjects1[i].hide();
}
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}

{ //Subevents
gdjs.GameSceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CameraLimitsBottom"), gdjs.GameSceneCode.GDCameraLimitsBottomObjects1);
gdjs.copyArray(runtimeScene.getObjects("CameraLimitsLeft"), gdjs.GameSceneCode.GDCameraLimitsLeftObjects1);
gdjs.copyArray(runtimeScene.getObjects("CameraLimitsRight"), gdjs.GameSceneCode.GDCameraLimitsRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("CameraLimitsTop"), gdjs.GameSceneCode.GDCameraLimitsTopObjects1);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.GameSceneCode.GDCameraLimitsLeftObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDCameraLimitsLeftObjects1[0].getAABBRight()), (( gdjs.GameSceneCode.GDCameraLimitsTopObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDCameraLimitsTopObjects1[0].getAABBBottom()), (( gdjs.GameSceneCode.GDCameraLimitsRightObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDCameraLimitsRightObjects1[0].getAABBLeft()), (( gdjs.GameSceneCode.GDCameraLimitsBottomObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDCameraLimitsBottomObjects1[0].getAABBTop()), "", 0);
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects1);

for (gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.GDPlayerObjectObjects1.length;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = 0;


gdjs.GameSceneCode.forEachTemporary2 = gdjs.GameSceneCode.GDPlayerObjectObjects1[gdjs.GameSceneCode.forEachIndex2];
gdjs.GameSceneCode.GDPlayerObjectObjects2.push(gdjs.GameSceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects2.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDPlayerObjectObjects2[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer()) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects2[k] = gdjs.GameSceneCode.GDPlayerObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.GameSceneCode.eventsList2(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects1);

for (gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.GDPlayerObjectObjects1.length;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("IndicatorArrow"), gdjs.GameSceneCode.GDIndicatorArrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.GameSceneCode.GDPlayerNameObjects2);
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = 0;


gdjs.GameSceneCode.forEachTemporary2 = gdjs.GameSceneCode.GDPlayerObjectObjects1[gdjs.GameSceneCode.forEachIndex2];
gdjs.GameSceneCode.GDPlayerObjectObjects2.push(gdjs.GameSceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].getBehavior("MultiplayerObject").getPlayerObjectOwnership() == (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getBehavior("MultiplayerObject").getPlayerObjectOwnership()) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects2[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerNameObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerNameObjects2[i].getBehavior("MultiplayerObject").getPlayerObjectOwnership() == (( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getBehavior("MultiplayerObject").getPlayerObjectOwnership()) ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerNameObjects2[k] = gdjs.GameSceneCode.GDPlayerNameObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerNameObjects2.length = k;
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorArrowObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorArrowObjects2[i].setPosition((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("")),(( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("")));
}
}
{for(var i = 0, len = gdjs.GameSceneCode.GDPlayerNameObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDPlayerNameObjects2[i].setPosition((( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointX("NamePoint")) - ((gdjs.GameSceneCode.GDPlayerNameObjects2[i].getWidth()) / 2),(( gdjs.GameSceneCode.GDPlayerObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDPlayerObjectObjects2[0].getPointY("NamePoint")));
}
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("IndicatorArrow"), gdjs.GameSceneCode.GDIndicatorArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.GameSceneCode.GDPlayerNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects1[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects1[k] = gdjs.GameSceneCode.GDPlayerObjectObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerNameObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerNameObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerNameObjects1[k] = gdjs.GameSceneCode.GDPlayerNameObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerNameObjects1.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("IndicatorArrow"), gdjs.GameSceneCode.GDIndicatorArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.GameSceneCode.GDPlayerNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("PlayerObject"), gdjs.GameSceneCode.GDPlayerObjectObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerObjectObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerObjectObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerObjectObjects1[k] = gdjs.GameSceneCode.GDPlayerObjectObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerObjectObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDIndicatorArrowObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDIndicatorArrowObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDIndicatorArrowObjects1[k] = gdjs.GameSceneCode.GDIndicatorArrowObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDPlayerNameObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDPlayerNameObjects1[i].getBehavior("MultiplayerObject").isObjectOwnedByCurrentPlayer() ) {
        isConditionTrue_0 = true;
        gdjs.GameSceneCode.GDPlayerNameObjects1[k] = gdjs.GameSceneCode.GDPlayerNameObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDPlayerNameObjects1.length = k;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList16(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.multiplayer.hasLobbyGameJustEnded();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lobby", false);
}
}

}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDPlayerObjectObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects5.length = 0;
gdjs.GameSceneCode.GDSawObjects1.length = 0;
gdjs.GameSceneCode.GDSawObjects2.length = 0;
gdjs.GameSceneCode.GDSawObjects3.length = 0;
gdjs.GameSceneCode.GDSawObjects4.length = 0;
gdjs.GameSceneCode.GDSawObjects5.length = 0;
gdjs.GameSceneCode.GDPickUpObjects1.length = 0;
gdjs.GameSceneCode.GDPickUpObjects2.length = 0;
gdjs.GameSceneCode.GDPickUpObjects3.length = 0;
gdjs.GameSceneCode.GDPickUpObjects4.length = 0;
gdjs.GameSceneCode.GDPickUpObjects5.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects4.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects5.length = 0;
gdjs.GameSceneCode.GDWallsObjects1.length = 0;
gdjs.GameSceneCode.GDWallsObjects2.length = 0;
gdjs.GameSceneCode.GDWallsObjects3.length = 0;
gdjs.GameSceneCode.GDWallsObjects4.length = 0;
gdjs.GameSceneCode.GDWallsObjects5.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects3.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects4.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects5.length = 0;
gdjs.GameSceneCode.GDScoreObjects1.length = 0;
gdjs.GameSceneCode.GDScoreObjects2.length = 0;
gdjs.GameSceneCode.GDScoreObjects3.length = 0;
gdjs.GameSceneCode.GDScoreObjects4.length = 0;
gdjs.GameSceneCode.GDScoreObjects5.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects1.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects2.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects3.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects4.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects5.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects1.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects2.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects3.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects4.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects5.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects5.length = 0;
gdjs.GameSceneCode.GDChatTextObjects1.length = 0;
gdjs.GameSceneCode.GDChatTextObjects2.length = 0;
gdjs.GameSceneCode.GDChatTextObjects3.length = 0;
gdjs.GameSceneCode.GDChatTextObjects4.length = 0;
gdjs.GameSceneCode.GDChatTextObjects5.length = 0;
gdjs.GameSceneCode.GDChatInputObjects1.length = 0;
gdjs.GameSceneCode.GDChatInputObjects2.length = 0;
gdjs.GameSceneCode.GDChatInputObjects3.length = 0;
gdjs.GameSceneCode.GDChatInputObjects4.length = 0;
gdjs.GameSceneCode.GDChatInputObjects5.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects5.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects1.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects2.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects3.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects4.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects5.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects1.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects2.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects3.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects4.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects5.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects5.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects1.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects2.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects3.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects4.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects5.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects1.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects2.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects3.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects4.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects5.length = 0;

gdjs.GameSceneCode.eventsList17(runtimeScene);
gdjs.GameSceneCode.GDPlayerObjectObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerObjectObjects5.length = 0;
gdjs.GameSceneCode.GDSawObjects1.length = 0;
gdjs.GameSceneCode.GDSawObjects2.length = 0;
gdjs.GameSceneCode.GDSawObjects3.length = 0;
gdjs.GameSceneCode.GDSawObjects4.length = 0;
gdjs.GameSceneCode.GDSawObjects5.length = 0;
gdjs.GameSceneCode.GDPickUpObjects1.length = 0;
gdjs.GameSceneCode.GDPickUpObjects2.length = 0;
gdjs.GameSceneCode.GDPickUpObjects3.length = 0;
gdjs.GameSceneCode.GDPickUpObjects4.length = 0;
gdjs.GameSceneCode.GDPickUpObjects5.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects1.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects2.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects3.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects4.length = 0;
gdjs.GameSceneCode.GDIndicatorArrowObjects5.length = 0;
gdjs.GameSceneCode.GDWallsObjects1.length = 0;
gdjs.GameSceneCode.GDWallsObjects2.length = 0;
gdjs.GameSceneCode.GDWallsObjects3.length = 0;
gdjs.GameSceneCode.GDWallsObjects4.length = 0;
gdjs.GameSceneCode.GDWallsObjects5.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects1.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects2.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects3.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects4.length = 0;
gdjs.GameSceneCode.GDWalls_9595SlipperyObjects5.length = 0;
gdjs.GameSceneCode.GDScoreObjects1.length = 0;
gdjs.GameSceneCode.GDScoreObjects2.length = 0;
gdjs.GameSceneCode.GDScoreObjects3.length = 0;
gdjs.GameSceneCode.GDScoreObjects4.length = 0;
gdjs.GameSceneCode.GDScoreObjects5.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects1.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects2.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects3.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects4.length = 0;
gdjs.GameSceneCode.GDPickUpUIObjects5.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects1.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects2.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects3.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects4.length = 0;
gdjs.GameSceneCode.GDUI_9595DarkCornerObjects5.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDBackgroundObjects5.length = 0;
gdjs.GameSceneCode.GDChatTextObjects1.length = 0;
gdjs.GameSceneCode.GDChatTextObjects2.length = 0;
gdjs.GameSceneCode.GDChatTextObjects3.length = 0;
gdjs.GameSceneCode.GDChatTextObjects4.length = 0;
gdjs.GameSceneCode.GDChatTextObjects5.length = 0;
gdjs.GameSceneCode.GDChatInputObjects1.length = 0;
gdjs.GameSceneCode.GDChatInputObjects2.length = 0;
gdjs.GameSceneCode.GDChatInputObjects3.length = 0;
gdjs.GameSceneCode.GDChatInputObjects4.length = 0;
gdjs.GameSceneCode.GDChatInputObjects5.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects1.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects2.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects3.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects4.length = 0;
gdjs.GameSceneCode.GDUI_9595ChatBackgroundObjects5.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects1.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects2.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects3.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects4.length = 0;
gdjs.GameSceneCode.GDSendButtonObjects5.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects1.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects2.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects3.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects4.length = 0;
gdjs.GameSceneCode.GDSpawnPointObjects5.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects1.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects2.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects3.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects4.length = 0;
gdjs.GameSceneCode.GDPlayerNameObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsLeftObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsRightObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsTopObjects5.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects1.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects2.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects3.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects4.length = 0;
gdjs.GameSceneCode.GDCameraLimitsBottomObjects5.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects1.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects2.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects3.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects4.length = 0;
gdjs.GameSceneCode.GDMobileButtonObjects5.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects1.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects2.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects3.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects4.length = 0;
gdjs.GameSceneCode.GDTutorialTextObjects5.length = 0;


return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
